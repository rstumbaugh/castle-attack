package com.rs.castleattack.game;

public enum Upgrade 
{
	FAST_SOLDIER, 
	BIG_SOLDIER,
	ARCHER,
	BIG_PROJECTILE,
	SMALL_PROJECTILE,
	AIR_STRIKE
}
