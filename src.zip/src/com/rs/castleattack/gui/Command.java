package com.rs.castleattack.gui;

public interface Command 
{
	public void doCommand();
}
